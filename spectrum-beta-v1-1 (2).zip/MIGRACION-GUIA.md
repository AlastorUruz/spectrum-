# Guía de migración: App 100% independiente de Base44

Esta guía contiene los pasos que deben ejecutarse **localmente** tras exportar el código,
ya que requieren eliminar dependencias de plataforma que no se pueden remover desde el entorno Base44.

---

## Estado actual

✅ **Ya hecho (desde Base44):**
- `capacitor.config.json` configurado con `appId: com.miapp.espectrograma`
- `public/manifest.json` con permisos PWA
- `public/favicon.svg` local (sin CDN externo)
- `src/api/client.js` — capa de API abstracta con `VITE_API_URL`
- `server/` — backend Node.js/Express independiente
- `.env.example` — plantilla de variables de entorno
- Scripts de Capacitor en `package.json` (`cap:sync`, `cap:add:android`, etc.)
- El núcleo de la app (espectrograma) ya es 100% offline/client-side

⬜ **Pendiente (local, tras exportar):**
- Eliminar `@base44/vite-plugin` del build
- Eliminar `@base44/sdk` de las dependencias
- Reescribir el sistema de auth (o eliminarlo)
- Instalar Capacitor y generar el APK

---

## Paso 1: Exportar el código

Descarga el código desde el dashboard de Base44 o clona el repositorio si tienes sincronización con GitHub.

---

## Paso 2: Eliminar dependencias de Base44

### 2a. Reescribir `vite.config.js`

Reemplaza todo el contenido con:

```js
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
});
```

### 2b. Eliminar paquetes de Base44

```bash
npm uninstall @base44/sdk @base44/vite-plugin
```

### 2c. Simplificar `src/App.jsx`

Reemplaza todo el contenido con (sin AuthProvider de Base44):

```jsx
import { Toaster } from "sonner";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
      <Toaster position="bottom-center" richColors closeButton />
    </Router>
  );
}

export default App;
```

### 2d. Eliminar archivos de auth de Base44

```bash
rm src/lib/AuthContext.jsx
rm src/components/ProtectedRoute.jsx
rm src/components/UserNotRegisteredError.jsx
rm src/lib/app-params.js          # si existe
rm src/lib/query-client.js        # si no usas react-query en otra parte
rm src/pages/Login.jsx            # si no necesitas login
rm src/pages/Register.jsx
rm src/pages/ForgotPassword.jsx
rm src/pages/ResetPassword.jsx
```

> Si necesitas autenticación, reimplementa un sistema propio con JWT
> conectado al backend de `server/`, o usa Firebase Auth / Supabase Auth.

### 2e. Eliminar `src/api/base44Client.js`

```bash
rm src/api/base44Client.js
```

La app ahora usa `src/api/client.js` (ya creada) como capa de API abstracta.

---

## Paso 3: Instalar Capacitor

```bash
npm install @capacitor/core
npm install -D @capacitor/cli
npm install @capacitor/android
```

---

## Paso 4: Compilar y empaquetar el APK

```bash
# 1. Compilar el frontend
npm run build

# 2. Sincronizar assets con Capacitor
npx cap sync

# 3. Añadir plataforma Android (solo la primera vez)
npx cap add android

# 4. Abrir en Android Studio
npx cap open android
```

En Android Studio:
1. Espera a que Gradle sincronice
2. Click en **Build → Build Bundle(s)/APK(s) → Build APK(s)**
3. El APK se genera en `android/app/build/outputs/apk/`

---

## Requisitos previos locales

- **Node.js** 18+
- **Android Studio** (incluye Android SDK)
- **Java JDK** 17 (incluido con Android Studio)

---

## Notas importantes

- La app de espectrograma **no necesita backend para funcionar**.
  Todo el procesamiento de audio es local (Web Audio API + Canvas).
- El `server/` solo es necesario si quieres sincronizar datos entre dispositivos.
- Si la app se va a usar sin login, el `App.jsx` simplificado del Paso 2c es suficiente.
- El `manifest.json` ya está configurado para PWA standalone en Android.