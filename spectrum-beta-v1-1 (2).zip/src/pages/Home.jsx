import React, { useState, useRef, useEffect, useCallback } from "react";
import { toast } from "sonner";
import Header from "@/components/spectra/Header";
import FileExplorer from "@/components/spectra/FileExplorer";
import SettingsPanel from "@/components/spectra/SettingsPanel";
import SlidePanel from "@/components/spectra/SlidePanel";
import SpectrogramCanvas from "@/components/spectra/SpectrogramCanvas";
import EmptyState from "@/components/spectra/EmptyState";
import { extractMetadata, isAudioFile, getFormat } from "@/lib/audioMetadata";
import { useTheme } from "@/lib/useTheme";

export default function Home() {
  const [fileList, setFileList] = useState([]);
  const [isLoadingFolder, setIsLoadingFolder] = useState(false);
  const [currentFile, setCurrentFile] = useState(null);
  const [audioBuffer, setAudioBuffer] = useState(null);
  const [isDecoding, setIsDecoding] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [explorerOpen, setExplorerOpen] = useState(() => typeof window !== "undefined" && window.innerWidth >= 768);
  const [settingsOpen, setSettingsOpen] = useState(() => typeof window !== "undefined" && window.innerWidth >= 768);
  const [settings, setSettings] = useState(() => {
    try {
      const s = JSON.parse(localStorage.getItem("spectra-settings") || "{}");
      return {
        palette: s.palette || "inferno",
        fftSize: s.fftSize || 1024,
        freqScale: s.freqScale || "log",
        gain: s.gain ?? 0,
        channel: 0,
        showCursorInfo: s.showCursorInfo ?? true
      };
    } catch {
      return { palette: "inferno", fftSize: 1024, freqScale: "log", gain: 0, channel: 0, showCursorInfo: true };
    }
  });
  const [prefs] = useState(() => {
    try { return JSON.parse(localStorage.getItem("spectra-settings") || "{}"); } catch { return {}; }
  });
  const [viewStart, setViewStart] = useState(0);
  const [visibleDur, setVisibleDur] = useState(0);
  const [decodedMeta, setDecodedMeta] = useState(null);
  const [nativeSampleRate, setNativeSampleRate] = useState(44100);
  const [freqMin, setFreqMin] = useState(20);
  const [freqMax, setFreqMax] = useState(22050);
  const { theme, toggleTheme, isDark } = useTheme();

  const audioRef = useRef(null);
  const audioCtxRef = useRef(null);
  const exportFnRef = useRef(null);
  const regraphFnRef = useRef(null);
  const [regraphActive, setRegraphActive] = useState(false);

  const getCtx = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    return audioCtxRef.current;
  };

  // rAF para actualizar el tiempo de reproducción
  useEffect(() => {
    let raf;
    const tick = () => {
      if (audioRef.current && !audioRef.current.paused) {
        setCurrentTime(audioRef.current.currentTime);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Reset frequency view range when scale or native sample rate changes
  useEffect(() => {
    setFreqMin(settings.freqScale === "log" ? 20 : 0);
    setFreqMax((nativeSampleRate || 44100) / 2);
  }, [settings.freqScale, nativeSampleRate]);

  const decodeFile = useCallback(async (file) => {
    setIsDecoding(true);
    try {
      const ctx = getCtx();
      if (ctx.state === "suspended") await ctx.resume();
      const arrayBuffer = await file.arrayBuffer();
      let buffer;
      try {
        buffer = await ctx.decodeAudioData(arrayBuffer.slice(0));
      } catch (e) {
        throw new Error("No se pudo decodificar el archivo. El formato podría no ser soportado por este navegador.");
      }
      if (audioRef.current && audioRef.current.src && audioRef.current.src.startsWith("blob:")) {
        URL.revokeObjectURL(audioRef.current.src);
      }
      const url = URL.createObjectURL(file);
      audioRef.current.src = url;
      setAudioBuffer(buffer);
      let meta = { format: getFormat(file.name) };
      try { meta = await extractMetadata(file); } catch (e) { /* ignore */ }
      setDecodedMeta({ ...meta, channels: buffer.numberOfChannels });
      setNativeSampleRate(meta.sampleRate || buffer.sampleRate);
      setCurrentFile({ name: file.name, format: getFormat(file.name), size: file.size });
      setCurrentTime(0);
      setDuration(buffer.duration);
      setViewStart(0);
      setVisibleDur(buffer.duration);
      setIsPlaying(false);
    } catch (e) {
      toast.error("Error de decodificación", { description: e.message });
    } finally {
      setIsDecoding(false);
    }
  }, [toast]);

  const handleSingleFile = (file) => { if (file) decodeFile(file); };

  const handleFolder = async (fileListObj) => {
    const files = Array.from(fileListObj).filter(isAudioFile);
    if (!files.length) {
      toast("Sin archivos", { description: "No se encontraron archivos de audio en la carpeta." });
      return;
    }
    const items = files.map((f, i) => ({
      id: `${f.webkitRelativePath || f.name}-${f.size}-${i}`,
      name: f.name,
      path: f.webkitRelativePath || f.name,
      format: getFormat(f.name),
      file: f,
      sampleRate: null,
      channels: null,
      bitrate: null,
      decoding: true
    }));
    setFileList((prev) => {
      const existing = new Set(prev.map((it) => it.id));
      return [...prev, ...items.filter((it) => !existing.has(it.id))];
    });
    setIsLoadingFolder(true);
    setExplorerOpen(true);
    for (let i = 0; i < items.length; i++) {
      let meta = {};
      try { meta = await extractMetadata(items[i].file); } catch (e) { /* ignore */ }
      const id = items[i].id;
      setFileList((prev) => prev.map((it) => (it.id === id ? { ...it, ...meta, decoding: false } : it)));
    }
    setIsLoadingFolder(false);
    if (files.length === 1) {
      selectFile(items[0]);
    } else {
      toast.success("Carpeta cargada", { description: `${files.length} archivos de audio añadidos.` });
    }
  };

  const selectFile = (entry) => {
    decodeFile(entry.file);
    if (typeof window !== "undefined" && window.innerWidth < 768) setExplorerOpen(false);
  };

  const togglePlay = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      const ctx = getCtx();
      if (ctx.state === "suspended") ctx.resume();
      a.play();
      setIsPlaying(true);
    } else {
      a.pause();
      setIsPlaying(false);
    }
  };

  const seek = (t) => {
    if (audioRef.current) {
      audioRef.current.currentTime = t;
      setCurrentTime(t);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f) handleSingleFile(f);
  };

  return (
    <div
      className="h-[100dvh] flex flex-col bg-appbg text-apptext overflow-hidden"
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
    >
      <audio ref={audioRef} onEnded={() => setIsPlaying(false)} onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || duration)} />
      <Header
        onSingleFile={handleSingleFile}
        onFolder={handleFolder}
        isPlaying={isPlaying}
        onTogglePlay={togglePlay}
        currentTime={currentTime}
        duration={duration}
        onSeek={seek}
        currentFileName={currentFile?.name}
        isDecoding={isDecoding}
        explorerOpen={explorerOpen}
        onToggleExplorer={() => setExplorerOpen((o) => !o)}
        settingsOpen={settingsOpen}
        onToggleSettings={() => setSettingsOpen((o) => !o)}
        onRegraph={() => regraphFnRef.current?.()}
        regraphActive={regraphActive}
        theme={theme}
        onToggleTheme={toggleTheme}
      />
      <div className="flex-1 flex overflow-hidden">
        <SlidePanel open={explorerOpen} onClose={() => setExplorerOpen(false)} side="left" overlay onOverlayClick={() => setExplorerOpen(false)}>
          <FileExplorer
            files={fileList}
            currentFileId={currentFile?.name}
            onSelect={selectFile}
            isLoading={isLoadingFolder}
            onClose={() => setExplorerOpen(false)}
            onClearAll={() => {
              setFileList([]);
              toast.success("Lista de archivos borrada");
            }}
          />
        </SlidePanel>
        <main className="flex-1 flex flex-col overflow-hidden relative">
          {audioBuffer ? (
            <>
              <div className="flex-1 overflow-hidden">
                <SpectrogramCanvas
                  audioBuffer={audioBuffer}
                  settings={settings}
                  nativeSampleRate={nativeSampleRate}
                  isDark={isDark}
                  currentTime={currentTime}
                  duration={duration}
                  viewStart={viewStart}
                  visibleDur={visibleDur}
                  freqMin={freqMin}
                  freqMax={freqMax}
                  onViewChange={(s, v) => { setViewStart(s); setVisibleDur(v); }}
                  onFreqChange={(fMin, fMax) => { setFreqMin(fMin); setFreqMax(fMax); }}
                  registerExport={(fn) => { exportFnRef.current = fn; }}
                  registerRegraph={(fn) => { regraphFnRef.current = fn; }}
                  onRegraphChange={setRegraphActive}
                  onRenderComplete={() => toast.success("Finalizado")}
                  showCrosshair={prefs.crosshair !== false}
                  showGrid={prefs.showGrid !== false}
                  showCursorInfo={settings.showCursorInfo !== false}
                />
              </div>
            </>
          ) : (
            <EmptyState onFolder={handleFolder} />
          )}
        </main>
        <SlidePanel open={settingsOpen} onClose={() => setSettingsOpen(false)} side="right" overlay onOverlayClick={() => setSettingsOpen(false)}>
          <SettingsPanel
            settings={settings}
            onChange={setSettings}
            metadata={decodedMeta}
            fileInfo={currentFile}
            onExport={() => exportFnRef.current?.()}
            onClose={() => setSettingsOpen(false)}
          />
        </SlidePanel>
      </div>
    </div>
  );
}