import React, { useState, useRef, useEffect, useCallback } from "react";
import { Upload, Play, Pause, Loader2, Music2 } from "lucide-react";
import { toast } from "sonner";
import SpectrogramCanvas from "@/components/spectra/SpectrogramCanvas";
import { extractMetadata, getFormat } from "@/lib/audioMetadata";

function fmtTime(s) {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  return `${m}:${Math.floor(s % 60).toString().padStart(2, "0")}`;
}

export default function SpectrogramSlot({ settings, label, accent }) {
  const [file, setFile] = useState(null);
  const [audioBuffer, setAudioBuffer] = useState(null);
  const [meta, setMeta] = useState(null);
  const [nativeSampleRate, setNativeSampleRate] = useState(44100);
  const [isDecoding, setIsDecoding] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [viewStart, setViewStart] = useState(0);
  const [visibleDur, setVisibleDur] = useState(0);
  const [freqMin, setFreqMin] = useState(20);
  const [freqMax, setFreqMax] = useState(22050);

  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const inputRef = useRef(null);

  const getCtx = () => {
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    return ctxRef.current;
  };

  useEffect(() => {
    setFreqMin(settings.freqScale === "log" ? 20 : 0);
    setFreqMax((nativeSampleRate || 44100) / 2);
  }, [settings.freqScale, nativeSampleRate]);

  useEffect(() => {
    let raf;
    const tick = () => {
      if (audioRef.current && !audioRef.current.paused) setCurrentTime(audioRef.current.currentTime);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const decode = useCallback(async (f) => {
    setIsDecoding(true);
    try {
      const ctx = getCtx();
      if (ctx.state === "suspended") await ctx.resume();
      const ab = await f.arrayBuffer();
      const buffer = await ctx.decodeAudioData(ab.slice(0));
      if (audioRef.current?.src?.startsWith("blob:")) URL.revokeObjectURL(audioRef.current.src);
      audioRef.current.src = URL.createObjectURL(f);
      setAudioBuffer(buffer);
      let m = { format: getFormat(f.name) };
      try { m = await extractMetadata(f); } catch (e) { /* ignore */ }
      setMeta({ ...m, channels: buffer.numberOfChannels });
      setNativeSampleRate(m.sampleRate || buffer.sampleRate);
      setFile({ name: f.name, format: getFormat(f.name) });
      setCurrentTime(0);
      setDuration(buffer.duration);
      setViewStart(0);
      setVisibleDur(buffer.duration);
      setIsPlaying(false);
    } catch (e) {
      toast.error("Error de decodificación", { description: e.message });
    } finally {
      setIsDecoding(false);
    }
  }, []);

  const togglePlay = () => {
    const a = audioRef.current;
    if (!a || !a.src) return;
    if (a.paused) {
      const ctx = getCtx();
      if (ctx.state === "suspended") ctx.resume();
      a.play();
      setIsPlaying(true);
    } else {
      a.pause();
      setIsPlaying(false);
    }
  };

  const seek = (t) => { if (audioRef.current) { audioRef.current.currentTime = t; setCurrentTime(t); } };

  return (
    <div className="flex flex-col h-full min-h-0 bg-[#0F1117] border border-white/10 rounded-lg overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10 bg-[#0b0d13]">
        <span className={`w-6 h-6 rounded flex items-center justify-center text-xs font-bold shrink-0 ${accent}`}>{label}</span>
        <button
          onClick={() => inputRef.current?.click()}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-200 text-xs border border-white/10 transition shrink-0"
        >
          <Upload size={13} /> Cargar
        </button>
        <span className="text-xs text-slate-400 truncate flex-1 min-w-0" title={file?.name}>{file?.name || "Sin archivo"}</span>
        {file && <span className="text-[10px] font-mono text-slate-500 shrink-0">{fmtTime(currentTime)}/{fmtTime(duration)}</span>}
        <button onClick={togglePlay} disabled={!file} className="w-7 h-7 rounded-full bg-white text-black flex items-center justify-center disabled:opacity-30 shrink-0">
          {isDecoding ? <Loader2 size={13} className="animate-spin" /> : isPlaying ? <Pause size={13} /> : <Play size={13} className="ml-0.5" />}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept=".mp3,.wav,.flac,.ogg,.m4a,.opus,.alac,.aac,audio/*"
          className="hidden"
          onChange={(e) => { if (e.target.files[0]) decode(e.target.files[0]); e.target.value = ""; }}
        />
      </div>
      <div className="flex-1 min-h-0 relative">
        {audioBuffer ? (
          <SpectrogramCanvas
            audioBuffer={audioBuffer}
            settings={settings}
            nativeSampleRate={nativeSampleRate}
            currentTime={currentTime}
            duration={duration}
            viewStart={viewStart}
            visibleDur={visibleDur}
            freqMin={freqMin}
            freqMax={freqMax}
            onViewChange={(st, v) => { setViewStart(st); setVisibleDur(v); }}
            onFreqChange={(a, b) => { setFreqMin(a); setFreqMax(b); }}
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-600 gap-2">
            <Music2 size={28} />
            <p className="text-xs">Carga un archivo de audio</p>
          </div>
        )}
        {isDecoding && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">
            <Loader2 size={20} className="animate-spin text-violet-400" />
          </div>
        )}
      </div>
      {file && (
        <div className="px-3 py-1.5 border-t border-white/10 bg-[#0b0d13] flex items-center gap-2">
          <input
            type="range"
            min={0}
            max={duration || 0}
            step={0.01}
            value={Math.min(currentTime, duration || 0)}
            onChange={(e) => seek(parseFloat(e.target.value))}
            className="flex-1 accent-violet-500"
          />
        </div>
      )}
      <audio ref={audioRef} onEnded={() => setIsPlaying(false)} />
    </div>
  );
}