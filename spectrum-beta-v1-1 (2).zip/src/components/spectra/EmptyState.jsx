import React, { useRef, useEffect, useState } from "react";
import { FolderOpen } from "lucide-react";

export default function EmptyState({ onFolder }) {
  const inputRef = useRef(null);
  const [pressed, setPressed] = useState(false);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.setAttribute("webkitdirectory", "");
      inputRef.current.setAttribute("directory", "");
    }
  }, []);

  return (
    <div className="flex-1 flex items-center justify-center p-10">
      <div className="text-center max-w-md">
        <button
          onClick={() => inputRef.current?.click()}
          onMouseDown={() => setPressed(true)}
          onMouseUp={() => setPressed(false)}
          onMouseLeave={() => setPressed(false)}
          onTouchStart={() => setPressed(true)}
          onTouchEnd={() => setPressed(false)}
          className={`w-20 h-20 mx-auto rounded-2xl bg-foreground/5 border flex items-center justify-center mb-5 transition-all duration-200 ${pressed ? "border-violet-500 shadow-[0_0_24px_4px_rgba(124,58,237,0.6)]" : "border-appborder hover:border-violet-500/50"}`}
          aria-label="Cargar carpeta"
        >
          <FolderOpen size={34} className="text-violet-400" />
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => { if (e.target.files.length) onFolder?.(e.target.files); e.target.value = ""; }}
        />
        <h2 className="text-lg font-semibold text-apptext mb-1">Carga un archivo de audio</h2>
        <p className="text-sm text-appmuted leading-relaxed">
          Usa los botones superiores para añadir un archivo o carpeta para comenzar el análisis espectral.
        </p>
      </div>
    </div>
  );
}