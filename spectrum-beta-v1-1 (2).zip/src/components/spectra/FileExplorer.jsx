import React, { useState } from "react";
import { Music2, Loader2, Trash2, X, AlertTriangle } from "lucide-react";

function fmtBR(b, vbr) {
  if (b == null) return vbr === true ? "VBR" : "—";
  return `${Math.round(b / 1000)}k${vbr === true ? " VBR" : vbr === false ? " CBR" : ""}`;
}
function fmtSR(s) {
  if (s == null) return "—";
  const k = s / 1000;
  return Number.isInteger(k) ? `${k}k` : `${k.toFixed(1)}k`;
}
function fmtCh(c) {
  if (c == null) return "—";
  const map = { 1: "Mono", 2: "St", 6: "5.1" };
  return map[c] || `${c}ch`;
}

export default function FileExplorer({ files, currentFileId, onSelect, isLoading, onClose, onClearAll }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  return (
    <aside
      className="relative w-80 max-w-[85vw] h-full bg-panel flex flex-col border-r border-appborder shadow-2xl md:shadow-none md:border-appborder md:shrink-0"
    >
      <div className="px-4 py-3 border-b border-appborder flex items-center gap-2">
        <Music2 size={14} className="text-violet-400" />
        <h2 className="text-sm font-semibold text-apptext">Archivos</h2>
        <span className="text-[11px] text-appmuted">({files.length})</span>
        {isLoading && <Loader2 size={14} className="animate-spin text-violet-400 ml-auto" />}
        {!isLoading && files.length > 0 && (
          <button
            onClick={() => setConfirmOpen(true)}
            title="Borrar lista de archivos"
            className="ml-auto p-1.5 rounded-md text-appmuted hover:text-red-400 hover:bg-red-500/10 transition"
          >
            <Trash2 size={14} />
          </button>
        )}
      </div>
      {confirmOpen && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-panel/95 backdrop-blur-sm p-4">
          <div className="w-full max-w-[260px] rounded-lg border border-appborder bg-appbg p-4 shadow-xl">
            <div className="flex items-start gap-2 mb-3">
              <AlertTriangle size={16} className="text-amber-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-apptext">¿Borrar todos los archivos?</p>
                <p className="text-[11px] text-appmuted mt-1 leading-relaxed">
                  Se eliminarán los {files.length} archivos de la lista. El archivo actualmente cargado se mantendrá en el espectrograma.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 justify-end">
              <button
                onClick={() => setConfirmOpen(false)}
                className="px-2.5 py-1.5 text-[11px] rounded-md text-appmuted hover:text-apptext hover:bg-foreground/5 transition"
              >
                Cancelar
              </button>
              <button
                onClick={() => { onClearAll?.(); setConfirmOpen(false); }}
                className="px-2.5 py-1.5 text-[11px] rounded-md bg-red-500/90 text-white hover:bg-red-500 transition flex items-center gap-1"
              >
                <Trash2 size={12} /> Borrar
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="flex-1 overflow-auto touch-pan-y">
        {files.length === 0 ? (
          <div className="p-6 text-center text-xs text-appmuted leading-relaxed">
            {isLoading ? "Leyendo cabeceras de la carpeta…" : "Selecciona una carpeta para ver sus archivos de audio."}
          </div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-panel text-appmuted z-10">
              <tr className="border-b border-appborder">
                <th className="px-3 py-2 font-medium">Nombre</th>
                <th className="px-2 py-2 font-medium">Fmt</th>
                <th className="px-2 py-2 font-medium" title="Bitrate">BR</th>
                <th className="px-2 py-2 font-medium" title="Sample Rate">SR</th>
                <th className="px-2 py-2 font-medium" title="Canales">Ch</th>
              </tr>
            </thead>
            <tbody>
              {files.map((f) => (
                <tr
                  key={f.id}
                  onClick={() => onSelect(f)}
                  className={`cursor-pointer touch-manipulation border-b border-appborder transition hover:bg-foreground/5 ${currentFileId === f.name ? "bg-violet-500/10" : ""}`}
                >
                  <td className="px-3 py-2 text-apptext truncate max-w-[150px]" title={f.path || f.name}>
                    <div className="truncate">{f.name}</div>
                    {f.path && f.path.includes("/") && (
                      <div className="text-[9px] text-appmuted truncate">{f.path.split("/").slice(0, -1).join("/")}</div>
                    )}
                  </td>
                  <td className="px-2 py-2 uppercase text-cyan-400">{f.format}</td>
                  <td className="px-2 py-2 text-appmuted">{f.decoding ? <Loader2 size={11} className="animate-spin" /> : fmtBR(f.bitrate, f.vbr)}</td>
                  <td className="px-2 py-2 text-appmuted">{fmtSR(f.sampleRate)}</td>
                  <td className="px-2 py-2 text-appmuted">{fmtCh(f.channels)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </aside>
  );
}