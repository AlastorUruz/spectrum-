import React, { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function SlidePanel({ open, onClose, side = "left", overlay = false, onOverlayClick, children }) {
  const [mounted, setMounted] = useState(open);
  const [translate, setTranslate] = useState(0);
  const [dragging, setDragging] = useState(false);
  const dragRef = useRef(null);
  const panelRef = useRef(null);

  const closeDir = side === "left" ? -1 : 1;
  const Icon = side === "left" ? ChevronLeft : ChevronRight;

  useEffect(() => {
    if (open) { setMounted(true); setTranslate(0); }
  }, [open]);

  useEffect(() => {
    if (!open && mounted) {
      const w = panelRef.current?.offsetWidth || 320;
      setTranslate(closeDir * w);
      const t = setTimeout(() => { setMounted(false); setTranslate(0); }, 300);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const onPointerDown = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    dragRef.current = { startX: e.clientX, startY: e.clientY, moved: false, id: e.pointerId };
  };
  const onPointerMove = (e) => {
    const d = dragRef.current;
    if (!d || d.id !== e.pointerId) return;
    const dx = e.clientX - d.startX;
    const dy = e.clientY - d.startY;
    if (!d.moved) {
      if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy) * 1.5) {
        d.moved = true;
        setDragging(true);
        try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      } else return;
    }
    const t = closeDir === -1 ? Math.min(0, dx) : Math.max(0, dx);
    setTranslate(t);
  };
  const onPointerUp = (e) => {
    const d = dragRef.current;
    if (!d) return;
    if (d.moved) {
      const w = panelRef.current?.offsetWidth || 320;
      if (Math.abs(translate) > w * 0.3) {
        onClose();
      } else {
        setTranslate(0);
      }
      setDragging(false);
    } else {
      onClose();
    }
    dragRef.current = null;
  };

  if (!mounted) return null;

  const sideClass = side === "left" ? "left-0" : "right-0";
  const btnSideClass = side === "left" ? "-right-4 rounded-r-md" : "-left-4 rounded-l-md";

  const panelWidth = panelRef.current?.offsetWidth || 320;
  const progress = Math.min(1, Math.abs(translate) / panelWidth);
  const r = Math.round(124 * progress);
  const g = Math.round(58 * progress);
  const b = Math.round(237 * progress);
  const btnBg = `rgb(${r}, ${g}, ${b})`;

  return (
    <>
      {overlay && (
        <div
          className={`md:hidden fixed inset-0 bg-black/50 z-20 transition-opacity duration-300 ${open ? "opacity-100" : "opacity-0 pointer-events-none"}`}
          onClick={onOverlayClick}
        />
      )}
      <div
        className={`fixed inset-y-0 ${sideClass} z-30 md:relative md:z-auto md:shrink-0`}
        style={{ transform: `translateX(${translate}px)`, transition: dragging ? "none" : "transform 0.3s ease" }}
      >
        <div ref={panelRef} className="relative h-full">
          {children}
          <button
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            aria-label="Cerrar menú"
            className={`absolute top-1/2 ${btnSideClass} -translate-y-1/2 z-40 h-[52px] w-[22px] flex items-center justify-center border border-white hover:brightness-125`}
            style={{ background: btnBg, transition: dragging ? "none" : "background 0.2s ease", touchAction: "none" }}
          >
            <Icon size={16} className="text-white" strokeWidth={2.5} />
          </button>
        </div>
      </div>
    </>
  );
}