import React, { useRef, useEffect, useState } from "react";

function formatTime(s) {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export default function WaveformCanvas({ audioBuffer, currentTime, duration, viewStart, visibleDur, onSeek, channel = 0 }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const peaksRef = useRef(null);
  const currentTimeRef = useRef(currentTime);
  currentTimeRef.current = currentTime;
  const [size, setSize] = useState({ w: 800, h: 100 });

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (!audioBuffer) return;
    const ch = audioBuffer.getChannelData(Math.min(channel, audioBuffer.numberOfChannels - 1));
    const samples = ch.length;
    const target = 5000;
    const block = Math.max(1, Math.floor(samples / target));
    const peaks = [];
    for (let i = 0; i < samples; i += block) {
      let min = 1, max = -1;
      for (let j = 0; j < block && i + j < samples; j++) {
        const v = ch[i + j];
        if (v < min) min = v;
        if (v > max) max = v;
      }
      peaks.push({ min, max });
    }
    peaksRef.current = peaks;
  }, [audioBuffer, channel]);

  useEffect(() => {
    let raf;
    const draw = () => {
      const canvas = canvasRef.current;
      if (canvas && peaksRef.current) {
        const dpr = window.devicePixelRatio || 1;
        const W = size.w, H = size.h;
        if (canvas.width !== W * dpr || canvas.height !== H * dpr) {
          canvas.width = W * dpr;
          canvas.height = H * dpr;
        }
        const ctx = canvas.getContext("2d");
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.fillStyle = "#0b0d13";
        ctx.fillRect(0, 0, W, H);

        const peaks = peaksRef.current;
        const mid = H / 2;
        const vDur = visibleDur || duration;
        const vStart = viewStart;
        const startIdx = Math.floor((vStart / duration) * peaks.length);
        const endIdx = Math.max(startIdx + 1, Math.ceil(((vStart + vDur) / duration) * peaks.length));
        const span = endIdx - startIdx;

        // center line
        ctx.strokeStyle = "rgba(255,255,255,0.05)";
        ctx.beginPath(); ctx.moveTo(0, mid); ctx.lineTo(W, mid); ctx.stroke();

        // waveform
        const grad = ctx.createLinearGradient(0, 0, 0, H);
        grad.addColorStop(0, "#06B6D4");
        grad.addColorStop(1, "#8B5CF6");
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = 0; x < W; x++) {
          const idx = startIdx + Math.floor((x / W) * span);
          if (idx < 0 || idx >= peaks.length) continue;
          const p = peaks[idx];
          const y1 = mid - p.max * mid * 0.9;
          const y2 = mid - p.min * mid * 0.9;
          ctx.moveTo(x, y1);
          ctx.lineTo(x, y2);
        }
        ctx.stroke();

        // playhead
        const ct = currentTimeRef.current;
        const px = ((ct - vStart) / vDur) * W;
        if (px >= 0 && px <= W) {
          ctx.strokeStyle = "rgba(255,255,255,0.9)";
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [size, viewStart, visibleDur, duration]);

  const handleClick = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const vDur = visibleDur || duration;
    onSeek(viewStart + px * vDur);
  };

  return (
    <div ref={containerRef} className="relative w-full h-full">
      <canvas ref={canvasRef} onClick={handleClick} className="block w-full h-full cursor-pointer" />
      <div className="absolute top-2 left-3 text-[10px] text-slate-600 uppercase tracking-wider pointer-events-none">Waveform</div>
    </div>
  );
}