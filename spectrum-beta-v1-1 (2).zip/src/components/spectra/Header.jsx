import React, { useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { Upload, FolderOpen, Play, Pause, FolderTree, Settings2, Loader2 } from "lucide-react";
import SpectrogramIcon from "@/components/spectra/SpectrogramIcon";
import HelpPopover from "@/components/spectra/HelpPopover";

function fmtTime(s) {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export default function Header({
  onSingleFile, onFolder, isPlaying, onTogglePlay, currentTime, duration, onSeek,
  currentFileName, isDecoding, explorerOpen, onToggleExplorer, settingsOpen, onToggleSettings,
  onRegraph, regraphActive, theme, onToggleTheme
}) {
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);

  useEffect(() => {
    if (folderInputRef.current) {
      folderInputRef.current.setAttribute("webkitdirectory", "");
      folderInputRef.current.setAttribute("directory", "");
    }
  }, []);

  return (
    <header className="border-b border-appborder bg-panel px-3 py-2 flex flex-wrap items-center gap-2 md:gap-4 md:px-4 md:py-2.5">
      <div className="flex items-center gap-2.5 shrink-0 order-1">
        <HelpPopover theme={theme} onToggleTheme={onToggleTheme} />
        <div className="hidden sm:block">
          <div className="font-semibold text-apptext leading-none tracking-tight">
            Spectrum<span className="text-violet-400">+</span>
          </div>
          <div className="text-[10px] text-appmuted leading-none mt-0.5">Análisis espectral</div>
        </div>
      </div>

      <nav className="hidden md:flex items-center gap-1 shrink-0 order-2">
        <Link to="/compare-audio" className="px-2.5 py-1.5 rounded-md text-xs text-appmuted hover:text-apptext hover:bg-foreground/5 transition">Comparar</Link>
        <Link to="/app-settings" className="px-2.5 py-1.5 rounded-md text-xs text-appmuted hover:text-apptext hover:bg-foreground/5 transition">Configuración</Link>
      </nav>

      <div className="flex items-center gap-2 shrink-0 order-2">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-violet-600 hover:bg-violet-500 text-white text-sm font-medium transition shadow-lg shadow-violet-600/20"
        >
          <Upload size={15} /> <span className="hidden md:inline">Cargar Archivo</span>
        </button>
        <button
          onClick={() => folderInputRef.current?.click()}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-foreground/5 hover:bg-foreground/10 text-apptext text-sm font-medium transition border border-appborder"
        >
          <FolderOpen size={15} /> <span className="hidden md:inline">Explorar Carpeta</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".mp3,.wav,.flac,.ogg,.m4a,.opus,.alac,.aac,audio/*"
          className="sr-only"
          onChange={(e) => { if (e.target.files[0]) onSingleFile(e.target.files[0]); e.target.value = ""; }}
        />
        <input
          ref={folderInputRef}
          type="file"
          multiple
          className="sr-only"
          onChange={(e) => { if (e.target.files.length) onFolder(e.target.files); e.target.value = ""; }}
        />
      </div>

      <div className="order-4 md:order-3 w-full md:w-auto md:flex-1 flex items-center gap-2 md:gap-3 min-w-0">
        <button
          onClick={onTogglePlay}
          disabled={!currentFileName}
          className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center disabled:opacity-40 hover:scale-105 transition shrink-0"
        >
          {isDecoding ? <Loader2 size={16} className="animate-spin" /> : isPlaying ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
        </button>
        <span className="text-xs font-mono text-appmuted tabular-nums shrink-0">{fmtTime(currentTime)}</span>
        <input
          type="range"
          min={0}
          max={duration || 0}
          step={0.01}
          value={Math.min(currentTime, duration || 0)}
          onChange={(e) => onSeek(parseFloat(e.target.value))}
          className="flex-1 accent-violet-500 min-w-0"
        />
        <span className="text-xs font-mono text-appmuted tabular-nums shrink-0">{fmtTime(duration)}</span>
      </div>

      <div className="flex items-center gap-1 shrink-0 order-3 md:order-4 ml-auto md:ml-0">
        <button
          onClick={onRegraph}
          className={`p-2 rounded-md border border-appborder transition ${regraphActive ? "bg-cyan-500/20 text-cyan-300" : "bg-foreground/5 text-appmuted hover:text-apptext"}`}
          title="Regraficar selección temporal"
        >
          <SpectrogramIcon size={16} />
        </button>
        <button
          onClick={onToggleExplorer}
          className={`p-2 rounded-md border border-appborder transition ${explorerOpen ? "bg-foreground/10 text-violet-300" : "bg-foreground/5 text-appmuted hover:text-apptext"}`}
          title="Explorador de archivos"
        >
          <FolderTree size={16} />
        </button>
        <button
          onClick={onToggleSettings}
          className={`p-2 rounded-md border border-appborder transition ${settingsOpen ? "bg-foreground/10 text-violet-300" : "bg-foreground/5 text-appmuted hover:text-apptext"}`}
          title="Ajustes"
        >
          <Settings2 size={16} />
        </button>
      </div>
    </header>
  );
}