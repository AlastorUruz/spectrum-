import React, { useState, useRef } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Sun, Moon, ChevronRight } from "lucide-react";

const TUTORIAL = `Spectrum+ — Guía rápida

CARGA DE ARCHIVOS
• Cargar Archivo: sube un único archivo de audio.
• Explorar Carpeta: importa todos los archivos de audio de una carpeta, incluidas las subcarpetas. Puedes cargar varias carpetas y se acumularán en el explorador. Si la carpeta tiene un solo archivo, se grafica automáticamente.
• También puedes arrastrar y soltar un archivo sobre la ventana.

EXPLORADOR DE ARCHIVOS (panel izquierdo)
• Lista los archivos con formato, bitrate, sample rate y canales.
• Haz clic en un archivo para decodificarlo y mostrar su espectrograma.

REPRODUCCIÓN
• Botón play/pausa y barra de búsqueda para desplazarte por el audio.

ESPECTROGRAMA
• Arrastra para desplazarte en tiempo y frecuencia.
• Pellizco (táctil) para hacer zoom.
• Mantén presionado 2 segundos sobre el espectrograma para entrar en modo selección.
• En modo selección, arrastra para definir una región temporal; puedes mover la selección arrastrándola dentro.
• Botón de regraficar (icono del espectrograma) para acercarte a la región seleccionada. Púlsalo de nuevo para volver a la vista completa.

PANEL DE AJUSTES (panel derecho)
• Paleta de colores, tamaño de ventana FFT, escala de frecuencia (log/lineal), ganancia y canal.
• Datos del cursor: activa o desactiva la información de frecuencia/tiempo que sigue al puntero sobre el espectrograma.
• Muestra los metadatos técnicos del archivo decodificado.
• Exportar PNG: genera una imagen HD 1920×1080 del espectrograma.

MODO CLARO/OSCURO
• Activa o desactiva el interruptor para cambiar el tema de toda la aplicación, incluido el fondo del espectrograma.`;

export default function HelpPopover({ theme, onToggleTheme }) {
  const [open, setOpen] = useState(false);
  const dragRef = useRef(null);
  const contentRef = useRef(null);
  const btnRef = useRef(null);
  const closeTimer = useRef(null);

  const applyTransform = (y, animate) => {
    const el = contentRef.current;
    if (!el) return;
    el.style.transition = animate ? "transform 0.25s ease" : "none";
    el.style.transform = y === 0 ? "" : `translateY(${y}px)`;
  };

  const applyButtonProgress = (dy) => {
    const btn = btnRef.current;
    if (!btn) return;
    const progress = Math.min(1, Math.abs(dy) / 100);
    const r = Math.round(124 * progress);
    const g = Math.round(58 * progress);
    const b = Math.round(237 * progress);
    btn.style.background = `rgb(${r}, ${g}, ${b})`;
  };

  const resetButton = () => {
    const btn = btnRef.current;
    if (!btn) return;
    btn.style.background = "rgb(0, 0, 0)";
  };

  const animateClose = () => {
    const el = contentRef.current;
    if (!el) { setOpen(false); return; }
    el.style.transition = "transform 0.25s ease, opacity 0.25s ease";
    el.style.transformOrigin = "top left";
    el.style.transform = "scale(0.1)";
    el.style.opacity = "0";
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpen(false), 250);
  };

  const handleOpenChange = (v) => {
    setOpen(v);
    if (v) { applyTransform(0, false); resetButton(); }
  };

  const onPointerDown = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    dragRef.current = { startX: e.clientX, startY: e.clientY, moved: false, id: e.pointerId };
  };
  const onPointerMove = (e) => {
    const d = dragRef.current;
    if (!d || d.id !== e.pointerId) return;
    const dx = e.clientX - d.startX;
    const dy = e.clientY - d.startY;
    if (!d.moved) {
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
        d.moved = true;
        try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      } else return;
    }
    applyTransform(dy, false);
    applyButtonProgress(dy);
  };
  const onPointerUp = (e) => {
    const d = dragRef.current;
    if (!d) return;
    if (d.moved) {
      const dy = e.clientY - d.startY;
      if (dy < -20) {
        animateClose();
      } else {
        applyTransform(0, true);
        resetButton();
      }
    } else {
      animateClose();
    }
    dragRef.current = null;
  };

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <button
          className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-violet-500/20 transition hover:scale-105"
          aria-label="Ayuda y tutorial"
        >
          <span className="text-black font-bold text-sm">S</span>
        </button>
      </PopoverTrigger>
      <PopoverContent ref={contentRef} align="start" sideOffset={8} className="relative w-80 bg-panel border-appborder text-apptext">
        <div className="space-y-3">
          <div>
            <div className="font-semibold text-sm text-apptext">Spectrum+</div>
            <div className="text-[11px] text-appmuted">Análisis espectral</div>
          </div>
          <div className="flex items-center justify-between py-2 border-y border-appborder">
            <div className="flex items-center gap-2 text-sm">
              {theme === "dark" ? <Moon size={15} className="text-appmuted" /> : <Sun size={15} className="text-appmuted" />}
              <span>Modo {theme === "dark" ? "oscuro" : "claro"}</span>
            </div>
            <Switch checked={theme === "dark"} onCheckedChange={onToggleTheme} />
          </div>
          <div className="max-h-72 overflow-y-auto touch-pan-y pr-1">
            <pre className="text-[11px] leading-relaxed text-appmuted whitespace-pre-wrap font-sans">{TUTORIAL}</pre>
          </div>
        </div>
        <button
          ref={btnRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          aria-label="Cerrar tutorial"
          className="absolute -bottom-4 left-1/2 -translate-x-1/2 z-40 h-[22px] w-[52px] flex items-center justify-center border border-white rounded-b-md hover:brightness-125"
          style={{ background: "rgb(0, 0, 0)", touchAction: "none" }}
        >
          <ChevronRight size={16} className="text-white" strokeWidth={2.5} style={{ transform: "rotate(-90deg)" }} />
        </button>
      </PopoverContent>
    </Popover>
  );
}