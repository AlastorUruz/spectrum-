import React, { useRef, useEffect, useState } from "react";
import { toast } from "sonner";
import { fft, hannWindow } from "@/lib/fft";
import { getPaletteColor } from "@/lib/colorPalettes";

const ML = 44, MR = 50, MB = 24, MT = 16;

function formatTime(s) {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export default function SpectrogramCanvas({
  audioBuffer, settings, nativeSampleRate, currentTime, duration,
  viewStart, visibleDur, freqMin, freqMax, onViewChange, onFreqChange,
  registerExport, registerRegraph, onSelectionChange, onRegraphChange, onRenderComplete,
  showCrosshair = true, showGrid = true, isDark = true, showCursorInfo = true
}) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const specRef = useRef(null);
  const renderRef = useRef(null);
  const renderDirty = useRef(true);
  const viewRef = useRef({ viewStart, visibleDur, duration, freqMin, freqMax, nyq: 22050 });
  const currentTimeRef = useRef(currentTime);
  const dragRef = useRef(null);
  const touchRef = useRef(null);
  const crosshairRef = useRef(null);
  const interactRef = useRef({ mode: "idle" });
  const longPressTimer = useRef(null);
  const selectionRef = useRef(null);
  const selModeRef = useRef(false);
  const guideYRef = useRef(null);
  const [size, setSize] = useState({ w: 800, h: 400 });
  const [regraphRange, setRegraphRange] = useState(null);
  const [cursorInfo, setCursorInfo] = useState(null);

  const nyq = (nativeSampleRate || audioBuffer?.sampleRate || 44100) / 2;

  const cBg = isDark ? "#000000" : "#ffffff";
  const cBorder = isDark ? "#ffffff" : "#0f172a";
  const cGrid = isDark ? "rgba(255,255,255,0.07)" : "rgba(15,23,42,0.08)";
  const cAxis = isDark ? "rgba(255,255,255,0.6)" : "rgba(15,23,42,0.65)";
  const cAxis2 = isDark ? "rgba(255,255,255,0.55)" : "rgba(15,23,42,0.6)";
  const cAxis3 = isDark ? "rgba(255,255,255,0.65)" : "rgba(15,23,42,0.7)";
  const cPlayhead = isDark ? "rgba(255,255,255,0.9)" : "rgba(15,23,42,0.85)";
  const cCross = isDark ? "rgba(255,255,255,0.7)" : "rgba(15,23,42,0.6)";
  const cBarBg = isDark ? "rgba(0,0,0,0.9)" : "rgba(255,255,255,0.9)";
  const cDbText = isDark ? "rgba(255,255,255,0.75)" : "rgba(15,23,42,0.7)";
  const bgRGB = isDark ? [0, 0, 0] : [255, 255, 255];

  currentTimeRef.current = currentTime;
  useEffect(() => {
    viewRef.current = { viewStart, visibleDur, duration, freqMin, freqMax, nyq };
  }, [viewStart, visibleDur, duration, freqMin, freqMax, nyq]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  // Reset selection/regraph on new audio
  useEffect(() => {
    setRegraphRange(null);
    selectionRef.current = null;
    selModeRef.current = false;
    guideYRef.current = null;
    interactRef.current = { mode: "idle" };
    onSelectionChange?.(false);
    onRegraphChange?.(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioBuffer]);

  // Compute spectrogram matrix with 75% overlap (Hann window)
  useEffect(() => {
    if (!audioBuffer) return;
    const fftSize = settings.fftSize;
    const chIdx = Math.min(settings.channel || 0, audioBuffer.numberOfChannels - 1);
    const channel = audioBuffer.getChannelData(chIdx);
    const fullLen = channel.length;
    const sr = audioBuffer.sampleRate;
    let rangeStart, rangeDur;
    if (regraphRange) {
      rangeStart = regraphRange.start;
      rangeDur = regraphRange.end - regraphRange.start;
    } else {
      rangeStart = 0;
      rangeDur = audioBuffer.duration;
    }
    const sIdx = Math.max(0, Math.floor(rangeStart * sr));
    const eIdx = Math.min(fullLen, Math.floor((rangeStart + rangeDur) * sr));
    const len = Math.max(fftSize, eIdx - sIdx);
    let hop = Math.max(1, Math.floor(fftSize * 0.25));
    let cols = Math.floor((len - fftSize) / hop) + 1;
    if (cols < 1) cols = 1;
    const maxCols = 4000;
    if (cols > maxCols) { hop = Math.ceil(len / maxCols); cols = Math.floor((len - fftSize) / hop) + 1; }
    const bins = fftSize / 2;
    const win = hannWindow(fftSize);
    const real = new Float32Array(fftSize);
    const imag = new Float32Array(fftSize);
    const db = new Float32Array(cols * bins);
    const eps = 1e-10;
    specRef.current = { db, cols, bins, bufferNyq: sr / 2, range: { start: rangeStart, dur: rangeDur }, computedCols: 0 };
    renderDirty.current = true;
    let cancelled = false;
    let c = 0;
    const chunk = Math.max(1, Math.ceil(cols / 60));
    const computeChunk = () => {
      if (cancelled) return;
      const end = Math.min(cols, c + chunk);
      for (; c < end; c++) {
        const start = c * hop;
        for (let i = 0; i < fftSize; i++) {
          const idx = sIdx + start + i;
          real[i] = (idx < eIdx ? channel[idx] : 0) * win[i];
          imag[i] = 0;
        }
        fft(real, imag);
        const base = c * bins;
        for (let b = 0; b < bins; b++) {
          const re = real[b], im = imag[b];
          const mag = Math.sqrt(re * re + im * im) / bins;
          db[base + b] = 20 * Math.log10(mag + eps);
        }
      }
      specRef.current = { db, cols, bins, bufferNyq: sr / 2, range: { start: rangeStart, dur: rangeDur }, computedCols: c };
      renderDirty.current = true;
      if (c < cols) {
        requestAnimationFrame(computeChunk);
      } else {
        onRenderComplete?.();
      }
    };
    requestAnimationFrame(computeChunk);
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioBuffer, settings.fftSize, settings.channel, regraphRange]);

  useEffect(() => {
    renderDirty.current = true;
  }, [settings, size, viewStart, visibleDur, freqMin, freqMax, duration, nativeSampleRate]);

  const freqAt = (fracY, fMin, fMax) => {
    if (settings.freqScale === "log" && fMin > 0) return fMax * Math.pow(fMin / fMax, fracY);
    return fMax - fracY * (fMax - fMin);
  };
  const fracAt = (f, fMin, fMax) => {
    if (settings.freqScale === "log" && fMin > 0) return Math.log(f / fMax) / Math.log(fMin / fMax);
    return (fMax - f) / (fMax - fMin);
  };

  const readCursorData = (cx, cy) => {
    const spec = specRef.current;
    if (!spec) return null;
    const { ix, iy, iw, ih } = innerRect();
    const fracX = (cx - ix) / iw;
    const fracY = (cy - iy) / ih;
    if (fracX < 0 || fracX > 1 || fracY < 0 || fracY > 1) return null;
    const vs = viewRef.current;
    const vDur = vs.visibleDur || vs.duration;
    const t = vs.viewStart + fracX * vDur;
    const fMax = vs.freqMax ?? vs.nyq;
    const fMin = vs.freqMin ?? 0;
    const freq = freqAt(fracY, fMin, fMax);
    const localT = (t - spec.range.start) / spec.range.dur;
    let dB = null;
    if (localT >= 0 && localT <= 1) {
      let col = Math.floor(localT * spec.cols);
      if (col >= spec.cols) col = spec.cols - 1;
      const done = spec.computedCols ?? spec.cols;
      if (col < done) {
        let bin = Math.round((freq / spec.bufferNyq) * spec.bins);
        if (bin < 0) bin = 0; else if (bin >= spec.bins) bin = spec.bins - 1;
        dB = spec.db[col * spec.bins + bin] + settings.gain;
      }
    }
    return { x: cx, y: cy, time: t, freq, dB };
  };

  const renderToCanvas = (RW, RH) => {
    const spec = specRef.current;
    const off = document.createElement("canvas");
    off.width = RW; off.height = RH;
    if (!spec) return off;
    const { db, cols, bins, bufferNyq, range } = spec;
    const vs = viewRef.current;
    const vStart = vs.viewStart;
    const vDur = vs.visibleDur || vs.duration;
    const fMax = vs.freqMax ?? vs.nyq;
    const fMin = vs.freqMin ?? 0;
    const gain = settings.gain;
    const octx = off.getContext("2d");
    const img = octx.createImageData(RW, RH);
    const data = img.data;
    for (let x = 0; x < RW; x++) {
      const t = vStart + (x / RW) * vDur;
      const localT = (t - range.start) / range.dur;
      if (localT < 0 || localT > 1) {
        for (let y = 0; y < RH; y++) {
          const idx = (y * RW + x) * 4;
          data[idx] = bgRGB[0]; data[idx + 1] = bgRGB[1]; data[idx + 2] = bgRGB[2]; data[idx + 3] = 255;
        }
        continue;
      }
      let col = Math.floor(localT * cols);
      if (col >= cols) col = cols - 1;
      const done = spec.computedCols ?? cols;
      if (col >= done) {
        for (let y = 0; y < RH; y++) {
          const idx = (y * RW + x) * 4;
          data[idx] = bgRGB[0]; data[idx + 1] = bgRGB[1]; data[idx + 2] = bgRGB[2]; data[idx + 3] = 255;
        }
        continue;
      }
      const base = col * bins;
      for (let y = 0; y < RH; y++) {
        const fracY = y / RH;
        const freq = freqAt(fracY, fMin, fMax);
        let bin = Math.round((freq / bufferNyq) * bins);
        if (bin < 0) bin = 0; else if (bin >= bins) bin = bins - 1;
        const dB = db[base + bin] + gain;
        const [r, g, b] = getPaletteColor(settings.palette, dB);
        const idx = (y * RW + x) * 4;
        data[idx] = r; data[idx + 1] = g; data[idx + 2] = b; data[idx + 3] = 255;
      }
    }
    octx.putImageData(img, 0, 0);
    return off;
  };

  const drawAxes = (ctx, ix, iy, iw, ih, W, H) => {
    const spec = specRef.current;
    if (!spec) return;
    const vs = viewRef.current;
    const fMax = vs.freqMax ?? vs.nyq;
    const fMin = vs.freqMin ?? 0;
    ctx.font = "10px ui-sans-serif, system-ui, sans-serif";
    ctx.strokeStyle = cGrid;
    ctx.fillStyle = cAxis;
    ctx.textAlign = "right";
    for (let f = 1000; f <= fMax; f += 1000) {
      if (f < fMin) continue;
      const y = iy + fracAt(f, fMin, fMax) * ih;
      if (y < iy || y > iy + ih) continue;
      if (showGrid) {
        ctx.beginPath(); ctx.moveTo(ix, y); ctx.lineTo(ix + iw, y); ctx.stroke();
      }
      ctx.fillText(`${f / 1000}k`, ix - 4, y + 3);
    }
    const vDur = vs.visibleDur || vs.duration;
    const vStart = vs.viewStart;
    const ticks = 6;
    ctx.textAlign = "center";
    ctx.fillStyle = cAxis2;
    for (let i = 0; i <= ticks; i++) {
      const t = vStart + (i / ticks) * vDur;
      ctx.fillText(formatTime(t), ix + (i / ticks) * iw, H - 7);
    }
    ctx.textAlign = "left";
    ctx.fillStyle = cAxis3;
    ctx.fillText("Hz", 2, H - 7);
  };

  const drawDbBar = (ctx, ix, iy, iw, ih, W, H) => {
    const barW = 15;
    const barX = ix + iw + 5;
    ctx.fillStyle = cBarBg;
    ctx.fillRect(barX, iy, barW, ih);
    for (let y = 0; y < ih; y++) {
      const db = 0 - (y / ih) * 120;
      const [r, g, b] = getPaletteColor(settings.palette, db);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(barX + 2, iy + y, barW - 4, 1);
    }
    ctx.fillStyle = cDbText;
    ctx.font = "9px ui-sans-serif, system-ui, sans-serif";
    ctx.textAlign = "left";
    for (let db = 0; db >= -120; db -= 10) {
      const y = iy + Math.max(6, Math.min(ih - 2, (-db / 120) * ih));
      ctx.fillText(`${db}`, barX + barW + 2, y + 3);
    }
    ctx.fillStyle = cCross;
    ctx.textAlign = "right";
    ctx.fillText("dB", W - 4, H - 7);
  };

  const doExport = () => {
    const spec = specRef.current;
    if (!spec) return;
    const W = 1920, H = 1080;
    const ix = ML, iy = MT, iw = W - ML - MR, ih = H - MB - MT;
    const off = renderToCanvas(iw, ih);
    const c = document.createElement("canvas");
    c.width = W; c.height = H;
    const ctx = c.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = cBg;
    ctx.fillRect(0, 0, W, H);
    ctx.drawImage(off, ix, iy, iw, ih);
    ctx.strokeStyle = cBorder;
    ctx.lineWidth = 1;
    ctx.strokeRect(ix, iy, iw, ih);
    drawAxes(ctx, ix, iy, iw, ih, W, H);
    drawDbBar(ctx, ix, iy, iw, ih, W, H);
    const a = document.createElement("a");
    a.download = `spectrogram_${Date.now()}.png`;
    a.href = c.toDataURL("image/png");
    a.click();
  };

  const finalizeSelection = () => {
    const sel = selectionRef.current;
    if (!sel) return;
    let a = Math.min(sel.a, sel.b), b = Math.max(sel.a, sel.b);
    const vs = viewRef.current;
    const vDur = vs.visibleDur || vs.duration;
    const minFrac = Math.min(1, Math.max(0.001, 1 / vDur));
    if (b - a < minFrac) {
      b = Math.min(1, a + minFrac);
      if (b - a < minFrac) a = Math.max(0, b - minFrac);
    }
    selectionRef.current = { a, b };
    onSelectionChange?.(b - a > 0);
  };

  const triggerRegraph = () => {
    const sel = selectionRef.current;
    if (sel) {
      const vs = viewRef.current;
      const vDur = vs.visibleDur || vs.duration;
      const tStart = vs.viewStart + Math.min(sel.a, sel.b) * vDur;
      const tEnd = vs.viewStart + Math.max(sel.a, sel.b) * vDur;
      if (tEnd - tStart < 0.05) return;
      setRegraphRange({ start: tStart, end: tEnd });
      onViewChange(tStart, tEnd - tStart);
      selectionRef.current = null;
      selModeRef.current = false;
      guideYRef.current = null;
      onSelectionChange?.(false);
      onRegraphChange?.(true);
      toast.success("Regraficando selección", { description: `Fragmento: ${tStart.toFixed(2)}s – ${tEnd.toFixed(2)}s` });
    } else if (regraphRange) {
      setRegraphRange(null);
      onViewChange(0, viewRef.current.duration);
      onRegraphChange?.(false);
      toast("Vista completa restaurada");
    } else if (selModeRef.current) {
      selModeRef.current = false;
      guideYRef.current = null;
      onSelectionChange?.(false);
    } else {
      toast("Mantén presionado 2s sobre el espectrograma para seleccionar una región");
    }
  };

  useEffect(() => { if (registerExport) registerExport(doExport); });
  useEffect(() => { if (registerRegraph) registerRegraph(triggerRegraph); });

  // Draw loop
  useEffect(() => {
    let raf;
    const draw = () => {
      const canvas = canvasRef.current;
      if (canvas && specRef.current) {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const W = size.w, H = size.h;
        const devW = Math.round(W * dpr), devH = Math.round(H * dpr);
        if (canvas.width !== devW || canvas.height !== devH) {
          canvas.width = devW; canvas.height = devH;
        }
        const ctx = canvas.getContext("2d");
        ctx.imageSmoothingEnabled = false;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, W, H);
        ctx.fillStyle = cBg;
        ctx.fillRect(0, 0, W, H);

        const ix = ML, iy = MT;
        const iw = Math.max(1, W - ML - MR);
        const ih = Math.max(1, H - MB - MT);

        if (renderDirty.current) {
          const rw = Math.min(Math.round(iw * dpr), 2400);
          const rh = Math.min(Math.round(ih * dpr), 1600);
          renderRef.current = renderToCanvas(rw, rh);
          renderDirty.current = false;
        }
        if (renderRef.current) {
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(renderRef.current, ix, iy, iw, ih);
        }
        ctx.strokeStyle = cBorder;
        ctx.lineWidth = 1;
        ctx.strokeRect(ix + 0.5, iy + 0.5, iw - 1, ih - 1);
        drawAxes(ctx, ix, iy, iw, ih, W, H);
        drawDbBar(ctx, ix, iy, iw, ih, W, H);

        // selection zone
        const sel = selectionRef.current;
        if (sel) {
          const x1 = ix + Math.min(sel.a, sel.b) * iw;
          const x2 = ix + Math.max(sel.a, sel.b) * iw;
          ctx.fillStyle = "rgba(124, 58, 237, 0.25)";
          ctx.fillRect(x1, iy, Math.max(1, x2 - x1), ih);
          ctx.strokeStyle = "rgba(167, 139, 250, 0.9)";
          ctx.lineWidth = 1;
          ctx.strokeRect(x1 + 0.5, iy + 0.5, Math.max(1, x2 - x1) - 1, ih - 1);
        }

        // playhead
        const vs = viewRef.current;
        const vDur = vs.visibleDur || vs.duration;
        const px = ix + ((currentTimeRef.current - vs.viewStart) / vDur) * iw;
        if (px >= ix && px <= ix + iw) {
          ctx.strokeStyle = cPlayhead;
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(px, iy); ctx.lineTo(px, iy + ih); ctx.stroke();
        }

        // guide line (selection mode) replaces crosshair
        if (selModeRef.current && guideYRef.current != null && guideYRef.current >= iy && guideYRef.current <= iy + ih) {
          ctx.strokeStyle = "rgba(34, 211, 238, 0.85)";
          ctx.lineWidth = 1;
          ctx.setLineDash([5, 4]);
          ctx.beginPath(); ctx.moveTo(ix, guideYRef.current); ctx.lineTo(ix + iw, guideYRef.current); ctx.stroke();
          ctx.setLineDash([]);
        } else if (showCrosshair) {
          const ch = crosshairRef.current;
          if (ch) {
            ctx.strokeStyle = cCross;
            ctx.lineWidth = 1;
            if (ch.x >= ix && ch.x <= ix + iw) {
              ctx.beginPath(); ctx.moveTo(ch.x, iy); ctx.lineTo(ch.x, iy + ih); ctx.stroke();
            }
            if (ch.y >= iy && ch.y <= iy + ih) {
              ctx.beginPath(); ctx.moveTo(ix, ch.y); ctx.lineTo(ix + iw, ch.y); ctx.stroke();
            }
            if (ch.x >= ix && ch.x <= ix + iw && ch.y >= iy && ch.y <= iy + ih) {
              ctx.fillStyle = cBorder;
              ctx.beginPath(); ctx.arc(ch.x, ch.y, 5, 0, Math.PI * 2); ctx.fill();
              ctx.lineWidth = 2; ctx.strokeStyle = cBorder;
              ctx.beginPath(); ctx.arc(ch.x, ch.y, 5, 0, Math.PI * 2); ctx.stroke();
            }
          }
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [size, settings, isDark]);

  const innerRect = () => {
    const W = size.w, H = size.h;
    return { ix: ML, iy: MT, iw: Math.max(1, W - ML - MR), ih: Math.max(1, H - MB - MT) };
  };
  const clientToX = (cx) => { const r = canvasRef.current.getBoundingClientRect(); return cx - r.left; };
  const clientToY = (cy) => { const r = canvasRef.current.getBoundingClientRect(); return cy - r.top; };
  const clientToFrac = (cx) => {
    const r = canvasRef.current.getBoundingClientRect();
    const { ix, iw } = innerRect();
    return Math.max(0, Math.min(1, ((cx - r.left) - ix) / iw));
  };

  const handleDown = (clientX, clientY) => {
    const vs = viewRef.current;
    const frac = clientToFrac(clientX);
    if (selModeRef.current) {
      const sel = selectionRef.current;
      if (sel && frac >= Math.min(sel.a, sel.b) && frac <= Math.max(sel.a, sel.b)) {
        interactRef.current = { mode: "moving", startFrac: frac, anchorA: sel.a, anchorB: sel.b };
      } else {
        selectionRef.current = { a: frac, b: frac };
        interactRef.current = { mode: "selecting", startFrac: frac };
        onSelectionChange?.(false);
      }
      return;
    }
    dragRef.current = { x: clientX, y: clientY, vStart: vs.viewStart, vDur: vs.visibleDur || vs.duration, fMin: vs.freqMin ?? 0, fMax: vs.freqMax ?? vs.nyq };
    interactRef.current = { mode: "awaitLong", startX: clientX, startY: clientY };
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
    longPressTimer.current = setTimeout(() => {
      selModeRef.current = true;
      guideYRef.current = clientToY(clientY);
      const f = clientToFrac(clientX);
      selectionRef.current = { a: f, b: f };
      interactRef.current = { mode: "selecting", startFrac: f };
    }, 2000);
  };

  const handleMove = (clientX, clientY) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cx = clientToX(clientX), cy = clientToY(clientY);
    const { ix, iy, iw, ih } = innerRect();
    const inside = cx >= ix && cx <= ix + iw && cy >= iy && cy <= iy + ih;
    if (selModeRef.current) {
      guideYRef.current = inside ? cy : null;
      crosshairRef.current = null;
      if (showCursorInfo) setCursorInfo(null);
    } else {
      crosshairRef.current = inside ? { x: cx, y: cy } : null;
      setCursorInfo(showCursorInfo && inside ? readCursorData(cx, cy) : null);
    }
    const it = interactRef.current;
    if (!it || it.mode === "idle") return;
    if (it.mode === "awaitLong") {
      if (Math.hypot(clientX - it.startX, clientY - it.startY) > 6) {
        if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
        it.mode = "panning";
      } else return;
    }
    if (it.mode === "panning") {
      const drag = dragRef.current;
      if (!drag) return;
      const vs = viewRef.current;
      const dxF = (clientX - drag.x) / iw;
      const dyF = (clientY - drag.y) / ih;
      const shift = -dxF * drag.vDur;
      let ns = Math.max(0, Math.min(vs.duration - drag.vDur, drag.vStart + shift));
      const span = drag.fMax - drag.fMin;
      let newFMin = drag.fMin + dyF * span;
      newFMin = Math.max(0, Math.min(vs.nyq - span, newFMin));
      onViewChange(ns, drag.vDur);
      onFreqChange(newFMin, newFMin + span);
      return;
    }
    if (it.mode === "selecting") {
      const frac = clientToFrac(clientX);
      selectionRef.current = { a: it.startFrac, b: frac };
      return;
    }
    if (it.mode === "moving") {
      const frac = clientToFrac(clientX);
      const delta = frac - it.startFrac;
      let newA = it.anchorA + delta, newB = it.anchorB + delta;
      const lo = Math.min(newA, newB), hi = Math.max(newA, newB);
      if (lo < 0) { newA -= lo; newB -= lo; }
      if (hi > 1) { newA -= (hi - 1); newB -= (hi - 1); }
      selectionRef.current = { a: newA, b: newB };
      return;
    }
  };

  const handleUp = () => {
    if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
    const it = interactRef.current;
    if (it && (it.mode === "selecting" || it.mode === "moving")) finalizeSelection();
    interactRef.current = { mode: "idle" };
    dragRef.current = null;
  };

  const onWheel = (e) => {
    const vs = viewRef.current;
    const rect = canvasRef.current.getBoundingClientRect();
    const { ix, iy, iw, ih } = innerRect();
    const px = ((e.clientX - rect.left) - ix) / iw;
    const py = ((e.clientY - rect.top) - iy) / ih;
    if (px < 0 || px > 1 || py < 0 || py > 1) return;
    const factor = e.deltaY > 0 ? 1.25 : 1 / 1.25;
    const dur = vs.duration;
    const vDur = vs.visibleDur || dur;
    const centerT = vs.viewStart + px * vDur;
    let newDur = Math.max(0.05, Math.min(dur, vDur * factor));
    let newStart = Math.max(0, Math.min(dur - newDur, centerT - px * newDur));
    const fMax = vs.freqMax ?? vs.nyq;
    const fMin = vs.freqMin ?? 0;
    const span = fMax - fMin;
    const cursorF = fMax - py * span;
    let newSpan = Math.max(50, Math.min(vs.nyq, span * factor));
    let newFMin = cursorF - (1 - py) * newSpan;
    newFMin = Math.max(0, Math.min(vs.nyq - newSpan, newFMin));
    onViewChange(newStart, newDur);
    onFreqChange(newFMin, newFMin + newSpan);
  };

  const onMouseDown = (e) => handleDown(e.clientX, e.clientY);
  const onMouseMove = (e) => handleMove(e.clientX, e.clientY);
  const onMouseUp = () => handleUp();
  const onMouseLeave = () => { handleUp(); crosshairRef.current = null; guideYRef.current = null; setCursorInfo(null); };

  const onTouchStart = (e) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleDown(t.clientX, t.clientY);
    } else if (e.touches.length === 2) {
      if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
      interactRef.current = { mode: "idle" };
      dragRef.current = null;
      const vs = viewRef.current;
      const rect = canvasRef.current.getBoundingClientRect();
      const { ix, iy, iw, ih } = innerRect();
      const a = e.touches[0], b = e.touches[1];
      const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      const px = (((a.clientX + b.clientX) / 2 - rect.left) - ix) / iw;
      const py = (((a.clientY + b.clientY) / 2 - rect.top) - iy) / ih;
      touchRef.current = { mode: "pinch", startDist: dist || 1, px, py, vStart: vs.viewStart, vDur: vs.visibleDur || vs.duration, fMin: vs.freqMin ?? 0, fMax: vs.freqMax ?? vs.nyq, dur: vs.duration, nyq: vs.nyq };
    }
  };

  const onTouchMove = (e) => {
    const st = touchRef.current;
    if (st && st.mode === "pinch" && e.touches.length === 2) {
      const a = e.touches[0], b = e.touches[1];
      const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      const factor = st.startDist / (dist || 1);
      const centerT = st.vStart + st.px * st.vDur;
      let newDur = Math.max(0.05, Math.min(st.dur, st.vDur * factor));
      let newStart = Math.max(0, Math.min(st.dur - newDur, centerT - st.px * newDur));
      const span = st.fMax - st.fMin;
      const cursorF = st.fMax - st.py * span;
      let newSpan = Math.max(50, Math.min(st.nyq, span * factor));
      let newFMin = cursorF - (1 - st.py) * newSpan;
      newFMin = Math.max(0, Math.min(st.nyq - newSpan, newFMin));
      onViewChange(newStart, newDur);
      onFreqChange(newFMin, newFMin + newSpan);
      return;
    }
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleMove(t.clientX, t.clientY);
    }
  };

  const onTouchEnd = (e) => {
    if (e.touches.length === 0) {
      touchRef.current = null;
      handleUp();
      crosshairRef.current = null;
      guideYRef.current = null;
    } else if (e.touches.length === 1) {
      touchRef.current = null;
      const t = e.touches[0];
      handleDown(t.clientX, t.clientY);
    }
  };

  const fmtFreq = (f) => (f >= 1000 ? `${(f / 1000).toFixed(2)} kHz` : `${Math.round(f)} Hz`);
  const fmtDb = (d) => (d == null ? "—" : `${d > 0 ? "+" : ""}${d.toFixed(1)} dB`);

  return (
    <div ref={containerRef} className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        onWheel={onWheel}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseLeave}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        className={`block w-full h-full touch-none ${selModeRef.current ? "cursor-row-resize" : "cursor-crosshair"}`}
        style={{ imageRendering: "pixelated" }}
      />
      {showCursorInfo && cursorInfo && (
        <div
          className="pointer-events-none absolute z-20 rounded-md border border-appborder bg-panel/95 backdrop-blur px-2.5 py-1.5 text-[11px] font-mono text-apptext shadow-xl"
          style={{
            left: Math.min(cursorInfo.x + 14, size.w - 150),
            top: Math.min(cursorInfo.y + 14, size.h - 70)
          }}
        >
          <div className="flex items-center gap-1.5"><span className="text-appmuted">t</span><span>{formatTime(cursorInfo.time)}</span></div>
          <div className="flex items-center gap-1.5"><span className="text-appmuted">f</span><span>{fmtFreq(cursorInfo.freq)}</span></div>
          <div className="flex items-center gap-1.5"><span className="text-appmuted">dB</span><span>{fmtDb(cursorInfo.dB)}</span></div>
        </div>
      )}
    </div>
  );
}