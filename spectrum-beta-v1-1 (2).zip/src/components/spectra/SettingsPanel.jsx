import React from "react";
import { Download, AudioLines, SlidersHorizontal } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

function Row({ label, value, mono }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-appmuted">{label}</span>
      <span className={`text-apptext text-right truncate ${mono ? "font-mono" : ""}`} title={value}>{value}</span>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-[11px] text-appmuted mb-1.5">{label}</label>
      {children}
    </div>
  );
}

export default function SettingsPanel({ settings, onChange, metadata, fileInfo, onExport, onClose }) {
  const set = (k, v) => onChange({ ...settings, [k]: v });
  const fmtSR = (s) => {
    if (s == null) return "—";
    const k = s / 1000;
    return Number.isInteger(k) ? `${k} kHz` : `${k.toFixed(1)} kHz`;
  };
  const fmtBR = (b, vbr) => {
    if (b == null) return vbr === true ? "VBR" : "—";
    const mode = vbr === true ? " VBR" : vbr === false ? " CBR" : "";
    return `${Math.round(b / 1000)} kbps${mode}`;
  };
  const codecStr = [metadata?.codec, metadata?.bitDepth ? `${metadata.bitDepth} bit` : null]
    .filter(Boolean)
    .join(", ") || "—";
  const sr = fmtSR(metadata?.sampleRate);
  const ch = metadata?.channels ? ({ 1: "Mono", 2: "Estéreo", 6: "5.1" }[metadata.channels] || `${metadata.channels} canales`) : "—";

  return (
    <aside
      className="relative w-72 max-w-[85vw] h-full bg-panel flex flex-col border-l border-appborder shadow-2xl md:shadow-none md:border-appborder md:shrink-0"
    >
      <div className="flex-1 overflow-y-auto touch-pan-y">
      <div className="p-4 border-b border-appborder">
        <div className="flex items-center gap-2 mb-3">
          <AudioLines size={14} className="text-cyan-400" />
          <h2 className="text-sm font-semibold text-apptext">Metadatos</h2>
        </div>
        <div className="space-y-1.5 text-xs">
          <Row label="Archivo" value={fileInfo?.name || "—"} mono />
          <Row label="Formato" value={(metadata?.format || fileInfo?.format || "—").toUpperCase()} />
          <Row label="Códec" value={codecStr} />
          <Row label="Sample Rate" value={sr} />
          <Row label="Canales" value={ch} />
          <Row label="Bitrate" value={fmtBR(metadata?.bitrate, metadata?.vbr)} />
          <Row label="Duración" value={metadata?.duration ? `${metadata.duration.toFixed(2)} s` : "—"} />
        </div>
      </div>

      <div className="p-4 border-b border-appborder">
        <div className="flex items-center gap-2 mb-3">
          <SlidersHorizontal size={14} className="text-violet-400" />
          <h2 className="text-sm font-semibold text-apptext">Espectrograma</h2>
        </div>
        <div className="space-y-3">
          <Field label="Paleta de colores">
            <Select value={settings.palette} onValueChange={(v) => set("palette", v)}>
              <SelectTrigger className="w-full h-8 bg-appbg border-appborder rounded px-2 text-xs text-apptext capitalize focus:outline-none focus:border-violet-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-appborder">
                {["inferno", "plasma", "viridis", "grayscale", "rainbow"].map((p) => (
                  <SelectItem key={p} value={p} className="text-xs capitalize focus:bg-violet-500/20">{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Tamaño de ventana FFT">
            <Select value={String(settings.fftSize)} onValueChange={(v) => set("fftSize", parseInt(v))}>
              <SelectTrigger className="w-full h-8 bg-appbg border-appborder rounded px-2 text-xs text-apptext focus:outline-none focus:border-violet-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-appborder">
                {[256, 512, 1024, 2048, 4096].map((n) => (
                  <SelectItem key={n} value={String(n)} className="text-xs focus:bg-violet-500/20">{n}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Escala de frecuencia">
            <Select value={settings.freqScale} onValueChange={(v) => set("freqScale", v)}>
              <SelectTrigger className="w-full h-8 bg-appbg border-appborder rounded px-2 text-xs text-apptext focus:outline-none focus:border-violet-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-appborder">
                <SelectItem value="log" className="text-xs focus:bg-violet-500/20">Logarítmica</SelectItem>
                <SelectItem value="linear" className="text-xs focus:bg-violet-500/20">Lineal</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label={`Ganancia: ${settings.gain > 0 ? "+" : ""}${settings.gain} dB`}>
            <input
              type="range"
              min={-40}
              max={40}
              step={1}
              value={settings.gain}
              onChange={(e) => set("gain", parseInt(e.target.value))}
              className="w-full accent-violet-500 touch-none"
            />
          </Field>
          {metadata?.channels >= 2 && (
            <Field label="Canal">
              <Select value={String(settings.channel || 0)} onValueChange={(v) => set("channel", parseInt(v))}>
                <SelectTrigger className="w-full h-8 bg-appbg border-appborder rounded px-2 text-xs text-apptext focus:outline-none focus:border-violet-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground border-appborder">
                  <SelectItem value="0" className="text-xs focus:bg-violet-500/20">Izquierdo</SelectItem>
                  <SelectItem value="1" className="text-xs focus:bg-violet-500/20">Derecho</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          )}
          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-appmuted">Datos del cursor</span>
            <Switch
              checked={settings.showCursorInfo !== false}
              onCheckedChange={(v) => set("showCursorInfo", v)}
            />
          </div>
        </div>
      </div>

      </div>
      <div className="p-4">
        <button
          onClick={onExport}
          className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition shadow-lg shadow-cyan-600/20"
        >
          <Download size={15} /> Exportar PNG
        </button>
        <p className="text-[10px] text-appmuted text-center mt-2">Imagen HD 1920×1080</p>
      </div>
    </aside>
  );
}