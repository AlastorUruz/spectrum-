import React from "react";

export default function SpectrogramIcon({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="specRainbowGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#ff0000" />
          <stop offset="16%" stopColor="#ff7f00" />
          <stop offset="33%" stopColor="#ffff00" />
          <stop offset="50%" stopColor="#00ff00" />
          <stop offset="66%" stopColor="#00ffff" />
          <stop offset="83%" stopColor="#0000ff" />
          <stop offset="100%" stopColor="#9b30ff" />
        </linearGradient>
      </defs>
      <rect x="2" y="9" width="2.5" height="6" rx="1" fill="url(#specRainbowGrad)" />
      <rect x="5.5" y="6" width="2.5" height="12" rx="1" fill="url(#specRainbowGrad)" />
      <rect x="9" y="3" width="2.5" height="18" rx="1" fill="url(#specRainbowGrad)" />
      <rect x="12.5" y="7" width="2.5" height="10" rx="1" fill="url(#specRainbowGrad)" />
      <rect x="16" y="5" width="2.5" height="14" rx="1" fill="url(#specRainbowGrad)" />
      <rect x="19.5" y="9" width="2.5" height="6" rx="1" fill="url(#specRainbowGrad)" />
    </svg>
  );
}