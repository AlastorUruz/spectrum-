/**
 * Capa de API abstracta y configurable.
 *
 * Permite desacoplar el frontend de cualquier backend específico.
 * La URL base se configura mediante la variable de entorno VITE_API_URL
 * en un archivo .env (ej: VITE_API_URL=https://mi-servidor.com/api).
 *
 * Si VITE_API_URL no está definida, las funciones operan en modo
 * offline/local (la app de espectrograma funciona 100% en el cliente).
 */

const API_URL = import.meta.env.VITE_API_URL || '';

async function request(path, options = {}) {
  if (!API_URL) {
    // Modo offline: la app funciona sin backend.
    return null;
  }

  const token = localStorage.getItem('auth_token');

  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(error.message || `Error ${res.status}`);
  }

  return res.status === 204 ? null : res.json();
}

export const api = {
  get: (path) => request(path, { method: 'GET' }),
  post: (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) }),
  put: (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) }),
  patch: (path, data) => request(path, { method: 'PATCH', body: JSON.stringify(data) }),
  delete: (path) => request(path, { method: 'DELETE' }),
};

/**
 * Almacenamiento local offline-first.
 * Usa localStorage para configuraciones del usuario.
 */
export const localStore = {
  get: (key, fallback = null) => {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : fallback;
    } catch {
      return fallback;
    }
  },
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('No se pudo guardar en localStorage:', e);
    }
  },
  remove: (key) => localStorage.removeItem(key),
};