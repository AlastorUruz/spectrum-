/**
 * Backend independiente para Spectroid+
 *
 * Este servidor NO depende de Base44. Puedes desplegarlo en:
 * - Render.com (gratis tier)
 * - Vercel (serverless)
 * - Cualquier VPS con Node.js
 *
 * Despliegue:
 *   1. cd server && npm install
 *   2. npm start
 *   3. Configura VITE_API_URL en el frontend (.env) apuntando a esta URL
 */

import express from 'express';
import cors from 'cors';
import multer from 'multer';

const app = express();
const PORT = process.env.PORT || 3001;

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Configuración de subida de archivos
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB
});

// --- Rutas de salud ---
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// --- Rutas de autenticación (ejemplo básico) ---
// Reemplaza con tu propio sistema de auth (JWT, Firebase Auth, Supabase Auth, etc.)
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  // TODO: Validar credenciales contra tu base de datos
  // Por ahora es un placeholder
  res.json({
    token: 'placeholder-jwt-token',
    user: { id: '1', email, name: 'Usuario' },
  });
});

app.post('/api/auth/register', (req, res) => {
  const { email, password } = req.body;
  // TODO: Crear usuario en tu base de datos
  res.json({
    token: 'placeholder-jwt-token',
    user: { id: '1', email, name: 'Usuario' },
  });
});

// --- Rutas de archivos de audio ---
app.post('/api/audio/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No se recibió ningún archivo' });
  }
  // TODO: Guardar el archivo en tu almacenamiento (S3, local, etc.)
  res.json({
    id: Date.now().toString(),
    filename: req.file.originalname,
    size: req.file.size,
    mimetype: req.file.mimetype,
  });
});

app.get('/api/audio/:id', (req, res) => {
  // TODO: Recuperar archivo por ID
  res.status(404).json({ message: 'No implementado' });
});

// --- Rutas de configuración de usuario ---
app.get('/api/settings', (req, res) => {
  // TODO: Obtener configuraciones del usuario desde tu base de datos
  res.json({});
});

app.put('/api/settings', (req, res) => {
  // TODO: Guardar configuraciones del usuario
  res.json({ status: 'saved' });
});

// --- Manejo de errores ---
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: err.message || 'Error interno del servidor' });
});

// --- Iniciar servidor ---
app.listen(PORT, () => {
  console.log(`✅ Servidor Spectroid+ corriendo en http://localhost:${PORT}`);
  console.log(`   Endpoint de salud: http://localhost:${PORT}/api/health`);
});