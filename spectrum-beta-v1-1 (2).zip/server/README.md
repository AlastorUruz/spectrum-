# Backend independiente para Spectroid+

Este servidor Node.js/Express es **100% independiente de Base44** y está listo para desplegarse en cualquier plataforma.

## Despliegue rápido

### Local
```bash
cd server
npm install
npm start
```
El servidor corre en `http://localhost:3001`.

### Render.com
1. Crea un nuevo Web Service en Render
2. Conecta tu repositorio
3. Root Directory: `server`
4. Build Command: `npm install`
5. Start Command: `npm start`

### Vercel (serverless)
Instala el adapter de Vercel para Express, o migra las rutas a API routes de Vercel.

### VPS (DigitalOcean, Linode, etc.)
```bash
cd server
npm install
pm2 start index.js --name spectroid-server
```
Configura Nginx como proxy inverso al puerto 3001.

## Conectar el frontend

Crea un archivo `.env` en la raíz del proyecto frontend:
```
VITE_API_URL=http://localhost:3001/api
```
Para producción, apunta a tu servidor desplegado:
```
VITE_API_URL=https://tu-servidor.com/api
```

## Endpoints disponibles

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/auth/login` | Iniciar sesión |
| POST | `/api/auth/register` | Registrarse |
| POST | `/api/audio/upload` | Subir archivo de audio |
| GET | `/api/audio/:id` | Obtener archivo |
| GET | `/api/settings` | Obtener configuración |
| PUT | `/api/settings` | Guardar configuración |

## Nota importante

La app de espectrograma funciona **100% en el cliente** (Web Audio API + Canvas).
Solo necesitas este backend si quieres sincronizar configuraciones entre dispositivos
o almacenar archivos de audio en un servidor remoto. Para uso offline puro, no es necesario.